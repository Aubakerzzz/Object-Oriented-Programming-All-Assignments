/*
Name:Abubaker
Roll#:1379
Sec :H
*/


#include "pch.h"
#include "Map.h"


KV::KV() {

	for (int i = 0; i < 6; i++) {
		for (int j = 0; j < 50; j++) {
			values[i][j] = '\0';
		}
	}
}

Map::Map() {

	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 50; j++) {
			KeyV[i].key[j] = '\0';
		}
	}

	for (int i = 0; i < 50; i++) {
		for (int j = 0; j < 6; j++) {
			for (int k = 0; k < 50; k++) {
				KeyV[i].values[j][k] = '\0';
			}
		}
	}
}

void Map::operator[](char *str) {

	for (int i = 0; i < 50; i++) {
		if (KeyV[i].key == "\0") {
			for (int j = 0; str[j] != '\0'; j++) {
				KeyV[i].key[j] == str[j];
			}
		}
	}
}

void Map::operator=(const char* arr) {

	for (int i = 0; i < 50; i++) {
		if (KeyV[i].key != NULL) {
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 50; j++) {
					if (KeyV[i].values[i][j] == '\0') {
						for (int k = 0; arr[k] != '\0'; k++) {
							KeyV[i].values[i][j] = arr[k];
						}
					}
				}
			}
		}
	}
}

void Map::operator+=(const char* arr) {

	for (int i = 0; i < 50; i++) {
		if (KeyV[i].key != NULL) {
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 50; j++) {
					if (KeyV[i].values[i][j] == '\0') {
						for (int k = 0; arr[k] != '\0'; k++) {
							KeyV[i].values[i][j] = arr[k];
						}
					}
				}
			} 
		}
	}
}

void Map::operator-=(const char* s) {
	
	for (int i = 0; i < 50; i++) {
		if (KeyV[i].key != NULL) {
			for (int i = 0; i < 6; i++) {
				for (int j = 0; j < 50; j++) {
					for (int k = 0; s[k] != '\0'; k++) {
						if (KeyV[i].values[i][j] = s[k]) 
							KeyV[i].values[i][j] = '\0';
						if (KeyV[i].values[i][j] != s[k])
							KeyV[i].values[i][j] = '\0';
					}
				}
			}
		}
	}
}





