#pragma once

class KV {
public:
	char key[50] = "\0";
	char values[6][50];
	KV();


};

class Map{
private:
	KV KeyV[50];
	Map();
public:
	void  operator[](char *str);
	void operator=(const  char *str);
	void operator+=(const char* arr);
	void operator-=(const char* s);
	
};

