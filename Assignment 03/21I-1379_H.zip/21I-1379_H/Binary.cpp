/*
Name :Abubaker
Roll#:1379
SEc:H
*/
#pragma once
#include <iostream>
#include <string>
#include <map>
using namespace std;


class Byte
{
public:
    string value = "\0";

    Byte()
    {
        value = "\0";
    }
    Byte(string v)
    {
        value = v;
    }

    Byte(const Byte& i)
    {
        value = i.value;
    }

    string twos_comp() //2's complement for binary subtraction
    {
        bool flag = 0;
        Byte res(value);
        for (int i = value.size() - 1; i >= 0; i--)
        {
            if (flag)
            {
                res.value[i] = (value[i] == '1') ? '0' : '1';
            }
            else
            {
                if (value[i] == '1')
                {
                    flag = 1;
                }
            }
        }
        return res.value;
    }

    Byte operator + (const Byte& obj)
    {
        string result = "";
        int temp = 0;
        int size_a = value.size() - 1;
        int size_b = obj.value.size() - 1;
        while (size_a >= 0 || size_b >= 0 || temp == 1)
        {
            temp += ((size_a >= 0) ? value[size_a] - '0' : 0);
            temp += ((size_b >= 0) ? obj.value[size_b] - '0' : 0);
            result = char(temp % 2 + '0') + result;
            temp /= 2;
            size_a--; size_b--;
        }
        Byte final(result);
        return final;
    }

    Byte operator - (Byte& obj)
    {
        //2's complement of string
        Byte obj2(obj.value);
        obj2.value = obj2.twos_comp(); //2's complement, then addition (so basically subtraction through addition)
        string result = "";
        int temp = 0;
        int size_a = value.size() - 1;
        int size_b = obj2.value.size() - 1;
        while (size_a >= 0 || size_b >= 0 || temp == 1)
        {
            temp += ((size_a >= 0) ? value[size_a] - '0' : 0);
            temp += ((size_b >= 0) ? obj2.value[size_b] - '0' : 0);
            result = char(temp % 2 + '0') + result;
            temp /= 2;
            size_a--; size_b--;
        }
        Byte final(result);
        return final;
    }

    bool operator == (const Byte& obj)
    {
        return value == obj.value;
    }

    bool operator || (const Byte& obj)
    {
        for (int i = 0; i < value.size() && i < obj.value.size(); i++)
        {
            if (value[i] != obj.value[i])
            {
                return false;
            }
        }
        return true;
    }

    bool operator && (const Byte& obj)
    {
        return value == obj.value;
    }

    friend ostream& operator<<(ostream& output, const Byte& B)
    {
        output << B.value;
        return output;
    }
};

class BinaryStore
{
public:
    map<string, string> store;
    int curr_idx = 0;
    int limit = 10;

    BinaryStore()
    {
        map<string, Byte> store;
        curr_idx = 0;
    }

    BinaryStore(int size)
    {
        map<string, string> store;
        curr_idx = 0;
    }

    void operator += (string str)
    {
        Byte temp;
        store[str] = temp.value;
    }

    void Add(string addr, Byte b)
    {
        if (curr_idx < limit)
        {
            store[addr] = b.value;
            curr_idx++;
        }
        else
        {
            cout << "\nLimit (" << limit << ") reached\n";
        }
    }

    friend ostream& operator<<(ostream& output, const BinaryStore& B)
    {
        for (const auto& elem : B.store)
        {
            output << elem.first << " " << elem.second << "\n";
        }
        return output;
    }

    Byte getByte(string addr)
    {
        string res = store[addr];
        Byte b(res);
        return b;
    }
};



