There are two classes 
1)Byte 
2)BinaryStore

1) In Byte class i perform the functions in which 2's complement for binary subtraction and returning 
the value whose function data type is string 
After that in Byte class i have overload two more operator one is addition and another is subtraction
in addition i calculate the size of both string and after by using while loop added the both string and returning the final result which 
is store in final
2) For Subtraction i have done 2's complement, then addition (so basically subtraction through addition) 
3)Then i overload == operator just returning value true or false
4)In || operator just cheking if values of string  are not same then returning false 
5) IN && operator i just return the value of the object 
6)Using ostream for output function 

2) In binary store class the addition operators are overloaded for performing the addition 
of the string and at last byte getByte function for returning the byteS