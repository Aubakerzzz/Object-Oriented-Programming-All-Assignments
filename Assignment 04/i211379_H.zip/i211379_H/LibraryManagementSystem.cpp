#include "pch.h"
#include "LibraryManagementSystem.h"
#include <string>
#include <iostream>
using namespace std;

Staff::Staff() {
	
	dept = "";
	designation = "";
}
void Staff::set_dept(string dep) {
	this->dept = dep;
}
void Staff::set_des(string des) {
	designation = des;
}
string Staff::get_des() {
	return this->designation;
}
string Staff::get_dept() {
	return this->dept;
}
Student::Student() {
	batch = "";
	designation = "";
}
void Student::set_batch(string batch) {
	this->batch = batch;
}
void Student::set_designation(string desgination) {
	this->designation = desgination;
}
string Student::get_batch() {
	return batch;
}
string Student::get_designation() {
	return designation;
}
User::User() {
	name = "";
	iD = 0;
}
void User::set_User(string name, int iD) {
	this->name = name;
	this->iD = iD;
}
string User::getName() {
	return name;
}
int User::get_ID() {
	return iD;
}
bool User::Verify(string name, int iD) {
	if (this->name == name && this->iD == iD)
		return true;
	return false;
}

bool User::Check_account() {
	if (this->name == name && this->iD == iD)
		return true;
	return false;
}

Account::Account() {
	no_borrowed_books = 0;
	no_lost_books = 0;
	no_reserved_books = 0;
	fine_amount = 0.0;
}
Account::Account(int borrow, int lost, int reserved, float fine_acc) {
	this->no_borrowed_books = borrow;
	this->no_lost_books = lost;
	this->no_reserved_books = reserved;
	this->fine_amount = fine_acc;

}
void Account::setAccounts(int b, int l, int r, float fine) {
	this->no_borrowed_books = b;
	this->no_lost_books = l;
	this->no_reserved_books = r;
	this->fine_amount = fine;

}
float Account::get_fine_amount() {
	return fine_amount;
}
int Account::get_no_borrowed_books() {
	return no_borrowed_books;
}
int Account::get_no_lost_books() {
	return no_lost_books;
}
int Account::get_no_reserved_books() {
	return no_reserved_books;
}
void Account::calculate_fine() {
	this->fine_amount = this->no_lost_books * 500;	//500 fine for losing each book
}

Page::Page() {
	text = "";
	page_number = 0;
}
Page::Page(string text, int page_number) {
	this->text = text;
	this->page_number = page_number;
}
void Page::set_text(string text) {
	this->text = text;
}
void Page::set_page_number(int page_number) {
	this->page_number = page_number;
}
string Page::get_text() {
	return this->text;
}
int Page::get_page_number() {
	return this->page_number;
}
LibraryDataBase::LibraryDataBase() {
	this->accounts = accounts;
	this->number_of_books = 0;
	this->List_Of_Books = new Book[50];
}
void LibraryDataBase::Add(Book b) {
	this->List_Of_Books[number_of_books] = b;
	this->number_of_books += 1;
}
void LibraryDataBase::Delete(string isbn) {
	int ind = 0;
	for (int i = 0; i < this->number_of_books; i++) {
		if (List_Of_Books[i].getiSBN() == isbn) {
			if (i == number_of_books) {
				number_of_books -= 1;
				return;
			}
			else {
				ind = i;
			}
		}
	}
	for (int j = ind; j < number_of_books; j++) {
		Book temp;
		temp = List_Of_Books[j];
		List_Of_Books[j] = List_Of_Books[j + 1];
		List_Of_Books[j + 1] = temp;
	}
}
void LibraryDataBase::Update(Book b) {
	for (int i = 0; i < number_of_books; i++) {
		if (b.getiSBN() == List_Of_Books[i].getiSBN())
			List_Of_Books[i] = b;
	}
}
void LibraryDataBase::Display() {
	for (int i = 0; i < number_of_books; i++) {
		cout << List_Of_Books[i].getTitle() << endl;
		cout << List_Of_Books[i].getAuthor() << endl;
		cout << List_Of_Books[i].getiSBN() << endl;
		cout << endl;
	}
}
void LibraryDataBase::Search(string isbn) {
	for (int i = 0; i < number_of_books; i++) {
		if (List_Of_Books[i].getiSBN() == isbn) {
			cout << List_Of_Books[i].getTitle() << endl;
			cout << List_Of_Books[i].getAuthor() << endl;
			cout << List_Of_Books[i].getiSBN() << endl;
			return;
		}
	}
	cout << "Book not found!" << endl;
}
Book::Book() {
	title = "";
	author = "";
	iSBN = "";
	date = "";
	reserved = false;
}
void Book::setFunBook(string t, string a, string i, bool reserved) {
	title = t;
	author = a;
	iSBN = i;
	this->reserved = reserved;
}
string Book::getTitle() {
	return title;
}
string Book::getAuthor() {
	return author;
}
string Book::getiSBN() {
	return iSBN;
}
void Book::set_reserved(bool r) {
	this->reserved = r;
}
void Book::dueDate() {

	cout << "Enter The Date Of Issue Book" << endl;
	cin >> date;
	cout << "Due Date Is :";
	cout << date;
}
void Book::reservation_status() {
	if (this->reserved) {
		cout << "Book already reserved" << endl;
	}
	else {
		cout << "Book available" << endl;
	}
}
void Book::Book_request() {
	if (!reserved) {
		reserved = true;
		cout << "Book request successfull" << endl;
	}
	else {
		reserved = false;
		cout << "Book not available" << endl;
	}
}
void Book::Renew_info(){
	if (!reserved) {
		cout << "Book is available" << endl;
	}
	else {
		cout << "Book will be available after 14 days" << endl;
	}
}

Librarian::Librarian() {
	name = "";
	password = "";
	iD = 0;
}
/*
Librarian::Librarian(string name, int users , string password) {
	this->password = password;
	this->name = name;
	this->iD = users;

}
*/
void Librarian::setFunction(string name, string password, int id) {
	this->password = password;
	this->name = name;
	this->iD = id;
}
string Librarian::getName() {
	return name;
}
string Librarian::getPass() {
	return password;
}
int Librarian::getID() {
	return iD;
}
bool Librarian::Verify_Librarian(string name, int id , string password) {

	if ((this->name == name)&&(this->iD = id) &&(this->password == password)) {
		return true;
	}
	return false;
}
bool Librarian::search_book() {

}
LibraryManagementSystem::LibraryManagementSystem() {

	//obj.setFunction(userName, userType, password);

	userType = 0;
	userName = "";
	password = "";
}
void LibraryManagementSystem::setLMS(int user, string name, string pass) {

	this->userType = user;
	this->userName = name;
	this->password = pass;
}
int LibraryManagementSystem::getUsers(int values) {
	return values;
}
string LibraryManagementSystem::Name(string name) {
	return name;
}
string LibraryManagementSystem::userPassword(string pass) {
	return pass;
}
bool LibraryManagementSystem::loginFunction(int user, string userName, string password) {

	if ((this->userType == user) && (this->userName == userName) && (this->password == password)) {
		return true;
	}
	return false;
}
bool LibraryManagementSystem::LogoutFunction(int user, string userName, string pasword) {

	if ((this->userType == user) && (this->userName == userName) && (this->password == password)) {
		return false;
	}
	return true;

}
void LibraryManagementSystem::registerFunction(int user, string userName, string password) {
	
	//obj.setFunction( name, password, id);

	this->userType = user;
	this->userName = userName;
	this->password = password;

	if ((userType != 0) && (userName != "") && (password != "")) {
		cout << "Successfully Registered!" << endl;
		cout << "Your Name :" << userName << endl;
		cout << "Your Password :" << password << endl;
	}
	else
		cout << "Sorry UserName or password must be more than 4 characeters" << endl;
}


int main() {

	LibraryManagementSystem lib_obj;
	
}
