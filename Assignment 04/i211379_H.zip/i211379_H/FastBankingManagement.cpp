#include "pch.h"
#include "FastBankingManagement.h"

Account::Account() {
	this->firstName = "";
	this->middleName = "";
	this->lastName = "";
	this->cnic_number = "";
	this->address = "";
	this->telephone_Number = "";
	this->dob = "";
	this->account_Number = 0;
	this->balance = 0;
	this->deposit_year = "";
	this->deposit_month = "";
	this->transaction_History = "";
}
void Account::setfirstName(string name) {
	this->firstName = name;
}
void Account::setmiddleName(string name) {
	this->middleName = name;
}
void Account::setlastName(string name) {
	this->lastName = name;
}
void Account::set_cnic(string cnic) {
	this->cnic_number = cnic;
}
void Account::set_address(string address) {
	this->address = address;
}
void Account::set_telephone(string tel) {
	this->telephone_Number = tel;
}
void Account::set_dob(string dob) {
	this->dob = dob;
}
void Account::set_acc_num(int acc) {
	this->account_Number = acc;
}
void Account::set_type(string type) {
	this->type = type;
}
void Account::set_balance(int bal) {
	this->balance = bal;
}
void Account::set_deposit_year(string year) {
	this->deposit_year = year;
}
void Account::set_deposit_month(string month) {
	this->deposit_month = month;
}
string Account::get_type() {
	return type;
}
string Account::get_firstName() {
	return firstName;
}
string Account::get_middleName() {
	return middleName;
}
string Account::get_lastName() {
	return lastName;
}
string Account::get_cnic() {
	return cnic_number;
}
string Account::get_address() {
	return address;
}
string Account::get_telephone() {
	return telephone_Number;
}
string Account::get_dob() {
	return dob;
}
int Account::get_accountNum() {
	return account_Number;
}
int Account::get_balance() {
	return balance;
}
string Account::get_deposit_year() {
	return deposit_year;
}
string Account::get_deposit_month() {
	return deposit_month;
}
void Account::display_History() {
	cout << this->transaction_History << endl;
}
void Account::deposit_money(int money) {
	this->balance += money;
	cout << "Amount deposited successfully!" << endl;
	cout << "Current Balance: " << this->balance << endl;
	this->transaction_History.append("\nAmount Deposited: " + to_string(money) + "Amount: " + to_string(this->balance));
}
void Account::withdraw_money(int money) {
	if (money > this->balance) {
		cout << "Insufficient balance!" << endl;
		return;
	}
	if (money > 5000) {
		if (this->balance - money - (0.002 * money) < 0) {
			cout << "Insufficient balance!" << endl;
			return;
		}
		else {
			this->balance = this->balance - money - (0.002 * money);
			cout << "Amount withdrawn successfully!" << endl;
			this->transaction_History.append("\nAmount Withdrawn: " + to_string(money) + "Amount: " + to_string(this->balance));
		}
	}
	if (money > 50000) {
		if (this->balance - money - (0.025 * money) < 0) {
			cout << "Insufficient balance!" << endl;
			return;
		}
		else {
			this->balance = this->balance - money - (0.025 * money);
			cout << "Amount withdrawn successfully!" << endl;
			this->transaction_History.append("\nAmount WIthdrawn: " + to_string(money) + "Amount: " + to_string(this->balance));
		}
	}
}
void Account::balance_inquiry() {
	cout << "Amount in the account: " << this->balance << endl;
}

int main() {
	//Bank can have total of 100 accounts
	int accounts = 0;
	Account *all_accounts;
	all_accounts = new Account[100];
	int option;
	while (true) {
		cout << "Enter (1) to Create a new account" << endl
			<< "Enter (2) to Use Existing User Options" << endl
			<< "Enter (3) to generate the list of all customers" << endl
			<< "Enter (4) to exit" << endl
			<< "Your option: ";
		cin >> option;
		if (option == 1) {
			string type, firstName, middleName, lastName, cnic, address, telephone, dob;
			cout << "Enter the account type: ";
			cin >> type;
			cout << "Enter first name: ";
			cin >> firstName;
			cout << "Enter middle name: ";
			cin >> middleName;
			cout << "Enter last name: ";
			cin >> lastName;
			cout << "Enter cnic: ";
			cin >> cnic;
			cout << "Enter address: ";
			cin >> address;
			cout << "Enter telephone: ";
			cin >> address;
			cout << "Enter dob: ";
			cin >> dob;
			all_accounts[accounts].set_type(type);
			all_accounts[accounts].setfirstName(firstName);
			all_accounts[accounts].setmiddleName(middleName);
			all_accounts[accounts].setlastName(lastName);
			all_accounts[accounts].set_cnic(cnic);
			all_accounts[accounts].set_address(address);
			all_accounts[accounts].set_telephone(telephone);
			all_accounts[accounts].set_dob(dob);
			if (accounts == 0) {
				all_accounts[accounts].set_acc_num(11985000);
			}
			else {
				all_accounts[accounts].set_acc_num(all_accounts[accounts].get_accountNum() + 1);
			}
			accounts += 1;
			cout << "Account Created Successfully!";
			cout << "Account Number: " << all_accounts[accounts - 1].get_accountNum() << endl;
		}
		else if (option == 2) {
			int op;
			cout << "Enter (1) to Generate Mini Statement of a Bank Customer" << endl
				<< "Enter (2) to Withdraw money from a customer account" << endl
				<< "Enter (3) to Deposit money" << endl
				<< "Enter (4) to Balance Inquiry" << endl
				<< "Enter (5) to Transaction history" << endl
				<< "Your option: ";
			cin >> op;
			if (op == 1) {
				int account_number;
				cout << "Enter account number: ";
				cin >> account_number;
				string cnic;
				cout << "Enter cnic: ";
				cin >> cnic;
				int ind = -1;
				for (int i = 0; i < accounts; i++) {
					if (all_accounts[i].get_accountNum() == account_number && all_accounts[i].get_cnic() == cnic) {
						ind = i;
						break;
					}
				}
				if (ind == -1)
					cout << "Account not found!" << endl;
				else {
					all_accounts[ind].display_History();
				}
			}
			else if (op == 2) {
				int account_number;
				cout << "Enter account number: ";
				cin >> account_number;
				string cnic;
				cout << "Enter cnic: ";
				cin >> cnic;
				int money;
				cout << "Enter the amount: ";
				cin >> money;
				int ind = -1;
				for (int i = 0; i < accounts; i++) {
					if (all_accounts[i].get_accountNum() == account_number && all_accounts[i].get_cnic() == cnic) {
						ind = i;
						break;
					}
				}
				if (ind == -1)
					cout << "Account not found!" << endl;
				else {
					if (money > 0) {
						all_accounts[ind].withdraw_money(money);
					}
				}
			}
			else if (op == 3) {
				int account_number;
				cout << "Enter account number: ";
				cin >> account_number;
				string cnic;
				cout << "Enter cnic: ";
				cin >> cnic;
				int money;
				cout << "Enter the amount: ";
				cin >> money;
				int ind = -1;
				for (int i = 0; i < accounts; i++) {
					if (all_accounts[i].get_accountNum() == account_number && all_accounts[i].get_cnic() == cnic) {
						ind = i;
						break;
					}
				}
				if (ind == -1)
					cout << "Account not found!" << endl;
				else {
					if (money > 0) {
						all_accounts[ind].deposit_money(money);
					}
				}
			}
			else if (op == 4) {
				int account_number;
				cout << "Enter account number: ";
				cin >> account_number;
				string cnic;
				cout << "Enter cnic: ";
				cin >> cnic;
				int ind = -1;
				for (int i = 0; i < accounts; i++) {
					if (all_accounts[i].get_accountNum() == account_number && all_accounts[i].get_cnic() == cnic) {
						ind = i;
						break;
					}
				}
				if (ind == -1)
					cout << "Account not found!" << endl;
				else {
					all_accounts[ind].balance_inquiry();
				}
			}
			else if (op == 5) {
				int account_number;
				cout << "Enter account number: ";
				cin >> account_number;
				string cnic;
				cout << "Enter cnic: ";
				cin >> cnic;
				int ind = -1;
				for (int i = 0; i < accounts; i++) {
					if (all_accounts[i].get_accountNum() == account_number && all_accounts[i].get_cnic() == cnic) {
						ind = i;
						break;
					}
				}
				if (ind == -1)
					cout << "Account not found!" << endl;
				else {
					all_accounts[ind].display_History();
				}
			}
			else {
				cout << "Invalid option!" << endl;
			}
		}
		else if (option == 3) {
			if (accounts == 0) {
				cout << "No account found!" << endl;
			}
			else {
				for (int i = 0; i < accounts; i++) {
					cout << "Account Number: " << all_accounts[i].get_accountNum() << endl;
					cout << "Account Type: " << all_accounts[i].get_type() << endl;
					cout << "Balance: " << all_accounts[i].get_balance() << endl;
					cout << endl;
				}
			}
		}
		else if (option == 4) {
			break;
		}
		else {
			cout << "Invalid Option" << endl;
		}
	}
	return 0;
}