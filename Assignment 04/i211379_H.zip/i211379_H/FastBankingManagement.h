#pragma once
#include<iostream>
#include<string>
using namespace std;

class Account {
private:
	string type;
	string firstName;
	string middleName;
	string lastName;
	string cnic_number;
	string address;
	string telephone_Number;
	string dob;
	int account_Number;
	int balance;
	string deposit_year;
	string deposit_month;
	string transaction_History;
public:
	Account();
	void setfirstName(string name);
	void setmiddleName(string name);
	void setlastName(string name);
	void set_cnic(string cnic);
	void set_address(string address);
	void set_telephone(string tel);
	void set_dob(string dob);
	void set_acc_num(int acc);
	void set_type(string type);
	void set_balance(int bal);
	void set_deposit_year(string year);
	void set_deposit_month(string month);
	string get_type();
	string get_firstName();
	string get_middleName();
	string get_lastName();
	string get_cnic();
	string get_address();
	string get_telephone();
	string get_dob();
	int get_accountNum();
	int get_balance();
	string get_deposit_year();
	string get_deposit_month();
	void display_History();
	void deposit_money(int money);
	void withdraw_money(int money);
	void balance_inquiry();
};




