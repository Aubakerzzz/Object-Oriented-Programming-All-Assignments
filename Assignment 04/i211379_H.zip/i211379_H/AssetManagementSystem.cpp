#include "pch.h"
#include "AssetManagementSystem.h"
#include <string>
#include <iostream>
using namespace std;

currency::currency() {
	ammount = 0;
}
void currency::set_Amount(int amm) {
	ammount = amm;
}
int currency::get_Amount() {
	return this->ammount;
}
int currency::profit_Calculator(int currentprice) {

	this->ammount -= currentprice;
	return this->ammount;

}
RealState::RealState() {

	area = "";
	location = "";
	years = 0;
	cost = 0;
	 current_market_value = 0;

}
void RealState::set_area(string area) {
	this->area = area;
}
void RealState::set_location(string location) {
	this->location = location;
}
void RealState::set_years(int years) {
	this->years = years;
}
void RealState::set_cost(int cost) {
	this->cost = cost;
}
void RealState::set_current_market(int currentValue) {
	this->current_market_value = currentValue;
}
string RealState::get_area() {
	return this->area;
}
string RealState::get_location() {
	return location;
}
int RealState::get_years() {
	return years;
}
int RealState::get_cost() {
	return cost;
}
int RealState::get_current_market() {
	return current_market_value;
}
int RealState:: calculating_profit(int current)  {
	this->cost -= current;
	return this->cost;
}
int Stock:: calcuate_profit(int currentPrice) {
	this->profit -= currentPrice;
	return this->profit;
}
SimpleStock::SimpleStock() {
	this->currentPrice = 0;
	this->totalCost = 0;
	this->totalStocks = 0;

}
void SimpleStock::set_totalStocks(int stocks) {
	totalStocks = stocks;
}
void SimpleStock::set_cost(int cost) {
	totalCost = cost;
}
void SimpleStock::set_price(int price) {
	currentPrice = price;
}
int SimpleStock::get_stock() {
	return totalStocks;
}
int SimpleStock::get_cost() {
	return totalCost;
}
int SimpleStock::get_price() {
	return currentPrice;
}
investors::investors() {
	cost = 0;
}
void investors::set_cost(int cost) {
	this->cost = cost;
}
void investors::add_price(int price) {

	this->cost += price;
	cout << "Total Price" << cost << endl;
}
void investors::sub_price(int price) {

	if (cost > price) {
		this->cost += price;
		cout << "Total Price" << this->cost << endl;

	}
	
}
int investors::profit(int current_cost) {

	this->cost -= current_cost;
	return this->cost;

}


