#pragma once
#include<string>
#include <iostream>
using namespace std;



class SimpleStock {
private:
	int totalStocks;
	int totalCost;
	int currentPrice;
public:
	SimpleStock();
	void set_totalStocks(int stocks);
	void set_cost(int cost);
	void set_price(int price);
	int get_stock();
	int get_cost();
	int get_price();
	
};
class Stock {
private:
	int profit;
	SimpleStock ob;
public:
	int calcuate_profit(int currentPrice);

};
class RealState {
private:
	string area;
	string location;
	int years;
	int cost;
	int current_market_value;
public:
	RealState();
	void set_area(string area);
	void set_location(string location);
	void set_years(int years);
	void set_cost(int cost);
	void set_current_market(int currentValue);
	string get_area();
	string get_location();
	int get_years();
	int get_cost();
	int get_current_market();
	int calculating_profit(int);
	

};
class currency {
private:
	int ammount;
public:
	currency();
	void set_Amount(int amm);
	int get_Amount();
	int profit_Calculator(int currentprice);

};
class Assets {
private:
	Stock obj1;
	RealState obj2;
	currency obj3;

};
class investors:public Assets, public currency , public RealState {
private:
	int cost;
public:
	investors();
	void set_cost(int cost);
	void add_price(int price);
	void sub_price(int price);
	int profit(int cost);
};
class AssetManagementSystem{
public:
	Assets obj;
	currency obj1;
	RealState obj2;
	Stock obj3;
	SimpleStock obj4;
};

