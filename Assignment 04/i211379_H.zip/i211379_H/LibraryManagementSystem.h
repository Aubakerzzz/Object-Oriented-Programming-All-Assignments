#pragma once
#include <string>
#include <iostream>
using namespace std;

class Account {
private:
	int no_borrowed_books;
	int no_lost_books;
	int no_reserved_books;
	float fine_amount;
public:
	Account();
	Account(int, int, int, float);
	void setAccounts(int, int, int, float);
	int get_no_borrowed_books();
	int get_no_lost_books();
	int get_no_reserved_books();
	float get_fine_amount();
	void calculate_fine();

};

class User {
private:
	string name;
	int iD;
	Account account;
public:
	User();
	void set_User(string name, int iD);
	string getName();
	int get_ID();
	bool Verify(string name, int iD);
	bool Check_account();
};


class Staff : public User{
private:
	string dept;
	string designation;
	Account account;
public:
	Staff();
	void set_dept(string dep);
	void set_des(string des);
	string get_dept();
	string get_des();
};

class Student : public User{
private:
	string batch;
	string designation;
public:
	Student();
	void set_batch(string);
	void set_designation(string);
	string get_batch();
	string get_designation();
};



class Page {
private:
	string text;
	int page_number;
public:
	Page();
	Page(string text, int page_number);
	void set_text(string text);
	void set_page_number(int page_number);
	string get_text();
	int get_page_number();
};

class Book {
private:
	string title;
	string author;
	string iSBN;
	string date;
	bool reserved;
	Page pages[100];
public:
	Book();
	void setFunBook(string t, string a, string i, bool reserved);
	string getTitle();
	string getAuthor();
	string getiSBN();
	void set_reserved(bool r);
	void dueDate();
	void reservation_status();
	void Book_request();
	void Renew_info();
};

class LibraryDataBase {
private:
	int number_of_books;
	Book *List_Of_Books;
	Account* accounts;
public:
	LibraryDataBase();
	void Add(Book book);
	void Delete(string iSBN);
	void Update(Book book);
	void Display();
	void Search(string iSBN);
};

class Librarian {
private:
	string name;
	string password;
	int iD;
public:
	Librarian();
	//Librarian(string name, int users, string password);
	void setFunction(string name, string password, int id);
	string getName();
	string getPass();
	int getID();
	bool Verify_Librarian(string name, int id , string password);
	bool search_book();
};

class LibraryManagementSystem{
private:
	Librarian libObj;
	Book bookObj;
	User userObj;
	int userType;
	string userName;
	string password;
public:
	LibraryManagementSystem();
	void setLMS(int user , string name , string pass);
	int getUsers(int values);
	string Name(string name);
	string userPassword(string pass);
	bool loginFunction(int user, string userName, string password);
	bool LogoutFunction(int user, string userName, string pasword);
	void registerFunction(int user, string userName, string password);
};


